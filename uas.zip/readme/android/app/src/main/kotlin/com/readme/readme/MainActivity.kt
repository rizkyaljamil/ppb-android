package com.readme.readme

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
