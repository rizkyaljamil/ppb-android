import 'package:flutter/material.dart';

class CustomColor {
  static const Color primaryColor = Color(0xFF0077FF);
  static const Color secondaryColor = Color(0xFF3399FF);
}
